wave_generator.zip为工程压缩包
coe格式文件为波形数值
