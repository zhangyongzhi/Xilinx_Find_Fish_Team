

/***************************** Include Files *******************************/
#include "axi_wave_generator.h"

/************************** Function Definitions ***************************/
